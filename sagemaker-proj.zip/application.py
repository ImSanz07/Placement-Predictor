from flask import Flask, render_template, request
import pickle
import numpy as np
import boto3

# model = pickle.load(open('model.pkl', 'rb'))
application = Flask(__name__)

s3 = boto3.client('s3')


def download_model_from_s3(bucket_name, file_key):
    file_path = '/tmp/model.pkl'  # Temporary directory to store the downloaded model
    s3.download_file(bucket_name, file_key, file_path)
    return file_path


bucket_name = 'placement-predictor'
file_key = 'model.pkl'
model_path = download_model_from_s3(bucket_name, file_key)
model = pickle.load(open(model_path, 'rb'))


@application.route('/')
def index():
    return render_template('index.html')


@application.route('/predict', methods=['POST'])
def predict_placement():
    cgpa = float(request.form.get('cgpa'))
    iq = int(request.form.get('iq'))
    profile_score = int(request.form.get('profile_score'))

    # prediction
    result = model.predict(np.array([cgpa, iq, profile_score]).reshape(1, 3))

    if result[0] == 1:
        result = 'placed'
    else:
        result = 'not placed'

    return render_template('index.html', result=result)


if __name__ == '__main__':
    application.run(host='127.0.0.1', port=8000)

# host='0.0.0.0',port=8080
